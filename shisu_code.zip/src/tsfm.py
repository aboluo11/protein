from lightai.core import *
from albumentations import *

mean = np.array([25.8022, 14.9129, 15.5262, 20.3930], dtype=np.float32)
std = np.array([41.7929, 29.0815, 42.3371, 31.1343], dtype=np.float32)


def get_img(row, sz, train):
    colors = ['red', 'green', 'blue', 'yellow']
    channels = []
    for color in colors:
        name = row['Id'] + f'_{color}.png'
        if train:
            # img_path = f'inputs/{sz}_full_external/{name}'
            img_path = f'inputs/{sz}_train/{name}'
        else:
            img_path = f'inputs/{sz}_test/{name}'
        channel = cv2.imread(img_path, -1)
        channels.append(channel)
    img = np.stack(channels, axis=-1)
    return img


def get_target(row):
    targets = row['Target'].split()
    targets = [int(t) for t in targets]
    res = np.zeros(28, dtype=np.float32)
    res[targets] = 1
    return res


class Tsfm:
    def __init__(self, sz, fair_img_tsfm=None, weighted_img_tsfm=None):
        self.sz = sz
        self.fair_img_tsfm = fair_img_tsfm
        self.weighted_img_tsfm = weighted_img_tsfm

    def __call__(self, row):
        img = get_img(row, self.sz, True)
        target = get_target(row)
        if self.fair_img_tsfm:
            img = self.fair_img_tsfm(image=img)['image']
        if self.weighted_img_tsfm:
            # weight = row['weight']
            # p = weight*0.25 + 0.5
            # if np.random.rand() < p:
            #     img = self.weighted_img_tsfm(image=img)['image']
            img = self.weighted_img_tsfm(image=img)['image']
        return img, target


class CropTsfm:
    def __init__(self, original_sz, crop_sz, fair_img_tsfm=None, weighted_img_tsfm=None):
        self.original_sz = original_sz
        self.crop_sz = crop_sz
        self.crop = RandomCrop(
            height=crop_sz, width=crop_sz, always_apply=True)
        self.fair_img_tsfm = fair_img_tsfm
        self.weighted_img_tsfm = weighted_img_tsfm

    def __call__(self, row):
        img = get_img(row, self.original_sz, True)
        img = self.crop(image=img)['image']
        target = get_target(row)
        if self.fair_img_tsfm:
            img = self.fair_img_tsfm(image=img)['image']
        if self.weighted_img_tsfm:
            weight = row['weight']
            p = weight*0.4 + 0.35
            if np.random.rand() < p:
                img = self.weighted_img_tsfm(image=img)['image']
            # img = self.weighted_img_tsfm(image=img)['image']
        return img, target


class TestTsfm:
    def __init__(self, sz, tta=True):
        self.sz = sz
        self.tta = tta

    def __call__(self, row):
        img = get_img(row, self.sz, False)
        if not self.tta:
            return img
        imgs = []
        brightcontrast = RandomBrightnessContrast(brightness_limit=(0.1, 0.2),
                                                  contrast_limit=(0.1, 0.2), always_apply=True)
        for transpose in [0, 1]:
            for h_flip in [0, 1]:
                for v_flip in [0, 1]:
                    tta = img
                    if transpose:
                        tta = np.transpose(tta, axes=(1, 0, 2))
                    if h_flip:
                        tta = tta[:, ::-1]
                    if v_flip:
                        tta = tta[::-1]
                    imgs.append(tta.copy())
        return imgs
