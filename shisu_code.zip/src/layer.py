from lightai.core import *


class Flatten(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        x = x.view(x.shape[0], -1)
        return x


def bn_drop_lin(n_in: int, n_out: int, bn: bool = True, p: float = 0., actn: Optional[nn.Module] = None):
    "Sequence of batchnorm (if `bn`), dropout (with `p`) and linear (`n_in`,`n_out`) layers followed by `actn`."
    layers = [nn.BatchNorm1d(n_in)] if bn else []
    if p != 0:
        layers.append(nn.Dropout(p))
    layers.append(nn.Linear(n_in, n_out))
    if actn is not None:
        layers.append(actn)
    return layers


def create_head(nf: int, nc: int, lin_ftrs: Optional[Collection[int]] = None, ps=[0.5],
                bn_final: bool = False):
    "Model head that takes `nf` features, runs through `lin_ftrs`, and about `nc` classes."
    lin_ftrs = [nf, 512, nc] if lin_ftrs is None else [nf] + lin_ftrs + [nc]
    if len(ps) == 1:
        ps = [ps[0]/2] * (len(lin_ftrs)-2) + ps
    actns = [nn.ReLU(inplace=True)] * (len(lin_ftrs)-2) + [None]
    layers = [AdaptiveConcatPool2d(), Flatten()]
    for ni, no, p, actn in zip(lin_ftrs[:-1], lin_ftrs[1:], ps, actns):
        layers += bn_drop_lin(ni, no, True, p, actn)
    if bn_final:
        layers.append(nn.BatchNorm1d(lin_ftrs[-1], momentum=0.01))
    # p = np.array([0.24836276, 0.01862812, 0.06592001, 0.02018652, 0.0311075,
    #               0.03600708, 0.0225878, 0.05703042, 0.00131585, 0.00119458,
    #               0.00110362, 0.01330407, 0.01354055, 0.00884108, 0.01632386,
    #               0.00038202, 0.00782235, 0.00270447, 0.01147885, 0.02226642,
    #               0.00265596, 0.08373557, 0.01654822, 0.06272436, 0.00259532,
    #               0.22658145, 0.00428107, 0.00077011])
    # layers[-1].bias.data = torch.Tensor(-np.log((1-p)/p))
    return nn.Sequential(*layers)


def conv_bn_relu(in_channels, out_channels, kernel_size, stride=1, padding=0, bn=True):
    conv = nn.Conv2d(in_channels, out_channels, kernel_size,
                     stride=stride, padding=padding, bias=False)
    if bn:
        bn = nn.BatchNorm2d(out_channels)
    relu = nn.ReLU(inplace=True)
    if bn:
        return nn.Sequential(conv, bn, relu)
    else:
        return nn.Sequential(conv, relu)


def bn_relu_conv(in_channels, out_channels, kernel_size, stride=1, padding=0):
    bn = nn.BatchNorm2d(in_channels)
    relu = nn.ReLU(inplace=True)
    conv = nn.Conv2d(in_channels, out_channels, kernel_size,
                     stride=stride, padding=padding, bias=False)
    return nn.Sequential(bn, relu, conv)


def upconv(in_channels, out_channels):
    conv = conv_bn_relu(in_channels, out_channels, kernel_size=3, padding=1)
    upconv = nn.ConvTranspose2d(
        out_channels, out_channels, kernel_size=3, stride=2, padding=1)
    return nn.Sequential(conv, upconv)


class AdaptiveConcatPool2d(nn.Module):
    "Layer that concats `AdaptiveAvgPool2d` and `AdaptiveMaxPool2d`."

    def __init__(self, sz: Optional[int] = None):
        "Output will be 2*sz or 2 if sz is None"
        super().__init__()
        sz = sz or 1
        self.ap, self.mp = nn.AdaptiveAvgPool2d(sz), nn.AdaptiveMaxPool2d(sz)

    def forward(self, x):
        return torch.cat([self.mp(x), self.ap(x)], 1)
