from lightai.core import *
from .layer import *


mean = T(np.array(
    [25.8022, 14.9129, 15.5262, 20.3930]).reshape((-1, 1, 1))).half()
std = T(np.array([41.7929, 29.0815, 42.3371, 31.1343]).reshape(
    (-1, 1, 1))).half()


class Model(nn.Module):
    def __init__(self, drop=0, base=torchvision.models.resnet18, pretrained=True):
        super().__init__()
        # self.inp_bn = nn.BatchNorm2d(4)
        self.base = self.get_base(base, pretrained)
        self.head = create_head(1024, 28, ps=[drop])

    def forward(self, x):
        x = x.half()
        x = x.permute(0, 3, 1, 2)
        x = (x-mean)/std
        # x = self.inp_bn(x)
        x = self.base(x)
        x = self.head(x)
        # x = torch.sigmoid(x)
        return x

    def get_base(self, base, pretrained):
        resnet = base(pretrained=pretrained)
        conv1 = nn.Conv2d(4, 64, kernel_size=(
            7, 7), stride=(2, 2), padding=(3, 3), bias=False)
        conv1.weight.data[:, :-1] = resnet.conv1.weight.data
        conv1.weight.data[:, -1] = resnet.conv1.weight.data.mean(dim=1)
        resnet.conv1 = conv1
        return nn.Sequential(*list(resnet.children())[:-2])


class Attention(nn.Module):
    def __init__(self, sz, base=torchvision.models.resnet18, pretrained=True):
        super().__init__()
        model = Model()
        self.encoder = model.base
        self.head = model.head
        self.decode_layers = []
        self.features = []
        self.sz = sz
        self.get_decoder()

    def forward(self, x):
        x = x.half()
        x = x.permute(0, 3, 1, 2)
        # x = (x-mean)/std

        x = self.encoder(x)
        logit = self.head(x)

        decoder_outputs = []
        for feature, layer in zip(self.features, self.decode_layers):
            out = layer(feature)
            out = out.float()
            out = F.interpolate(
                out, self.sz, mode='bilinear', align_corners=True)
            out = out.half()
            decoder_outputs.append(out)
        self.features = []

        decoded_img = torch.cat(decoder_outputs, dim=1)
        decoded_img = self.decode_final(decoded_img)

        return [logit, decoded_img]

    def get_decoder(self):
        handles = []
        for child in self.encoder.children():
            if isinstance(child, nn.MaxPool2d):
                continue
            handle = child.register_forward_hook(
                lambda module, _, feature: self.features.append(feature))
            handles.append(handle)
        x = torch.zeros(1, 4, self.sz, self.sz)
        with torch.no_grad():
            self.encoder.eval()
            self.encoder(x)
        cur_w = self.sz
        total_channel = 0
        for feature, handle in zip(self.features, handles):
            if feature.shape[-1] < cur_w:
                cur_w = feature.shape[-1]
                layer = nn.Conv2d(
                    feature.shape[1], 16, kernel_size=3, padding=1)
                self.decode_layers.append(layer)
                total_channel += 16
            else:
                handle.remove()
        self.decode_final = bn_relu_conv(
            total_channel, 4, kernel_size=3, padding=1)
        self.decode_layers = nn.ModuleList(self.decode_layers)
        self.features = []
