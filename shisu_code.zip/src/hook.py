from lightai.core import *
from lightai.callback import *
import heapq


class FindLargeLoss(Callback):
    def __init__(self):
        self.heap = []

    def on_batch_end(self, trn_loss):
        heapq.heappush(self.heap, trn_loss)
