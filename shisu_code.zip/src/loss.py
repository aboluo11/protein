from lightai.core import *
from lightai.callback import Callback

inverse_portion = [4.02636848,   53.68229167,   15.16990157,   49.5379994,
                   32.14658869,   27.77231391,   44.27167785,   17.53450292,
                   759.96313364,  837.11675127,  906.10989011,   75.16499544,
                   73.85221675,  113.10836763,   61.26002972, 2617.65079365,
                   127.83875969,  369.75784753,   87.11674591,   44.91067538,
                   376.51141553,   11.94235643,   60.42946134,   15.94276875,
                   385.30841121,    4.41342397,  233.58640227, 1298.51968504]


def f1_loss(predict, target):
    loss = 0
    fp = predict[target == 0]
    loss += ((fp.exp()+1).log()*fp.sigmoid()**2).mean()
    predict = torch.sigmoid(predict)
    # lack_cls = target.sum(dim=0) == 0
    # if lack_cls.any():
    #     #     #     loss += F.binary_cross_entropy_with_logits(
    #     #     #         predict[:, lack_cls], target[:, lack_cls]) * 0.5
    #     loss += predict[:, lack_cls].mean()
    tp = predict * target
    tp = tp.sum(dim=0)
    predict = predict.sum(dim=0)
    target = target.sum(dim=0)
    precision = tp / (predict + 1e-8)
    recall = tp / (target + 1e-8)
    f1 = 2 * (precision * recall / (precision + recall + 1e-8))
    # if lack_cls.any():
    #     f1[lack_cls] = 2 / (2 + predict[lack_cls])
    return 1 - f1.mean() + loss


class FocalLoss:
    def __init__(self, degree):
        self.degree = degree
        self.pos_weight = torch.Tensor(inverse_portion).cuda().log()

    def __call__(self, logit, target):
        loss = F.binary_cross_entropy_with_logits(
            logit, target, reduction='none', pos_weight=self.pos_weight)
        mul = target * (1 - logit.sigmoid()) + (1 - target) * logit.sigmoid()
        # mul = target + (1 - target) * logit.sigmoid()
        loss = mul**self.degree * loss
        # loss = loss.clamp(max=10)
        return loss.mean()


class AttentionLoss(Callback):
    def __init__(self):
        self.x = None

    def on_loss_begin(self, x, **kwargs):
        self.x = x.permute(0, 3, 1, 2)

    def __call__(self, predict, target):
        logit, decoded_img = predict
        classify_loss = f1_loss(logit, target)
        local_loss = F.mse_loss(decoded_img, self.x)
        return classify_loss + local_loss
